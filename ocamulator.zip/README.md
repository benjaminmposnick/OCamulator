# OCamulator
Mathematical solver in OCaml
